#include <iostream>
#include <string>
using namespace std;

bool FA(string s){
	char ch = s[0];
	int state = 0;
	int i=0;
	while(i != s.size()){
		ch = s[i];
		if((state==0) && (ch=='1')){
			state = 1;
		}else if(state == 1){
			if(ch=='0'){
				state = 0;
			}else{
				state = 2;
			}
		}else if(state == 2){
			if(ch=='0'){
				state = 0;
			}else{
				state = 3;
				break;
			}
		}
		i++;
	}
	
	return (state==3);
}

bool check(string s){
	int i=0;
	while(i!=s.size()){
		char ch = s[i];
		if(ch!='0' && ch!= '1'){
			cout << "\nThe string must only consist of 0 or 1. Try again\n";
			return false;
		}
		i++;
	}
	return true;
}

int main(){
	
	cout << "R.E.: (0+1)*111(0+1)*\n";
	string s;
	int ch;
	do{
		cout << "========MENU========\n\
0. Exit.\n\
1. Check a string if it belongs to the above automata or not.\n\
Enter Your Choice: ";
		cin >> ch;
		
		if(ch!=0 && ch!=1){
			cout << "\nInvalid Input, Try Again.\n";
		}
		
		if(ch == 1){
			string s;
			cout << "Enter string: ";
			cin >> s;
			if(check(s)){
				if(FA(s)){
					cout << "Given string is accepted in the automata\n";
				}else{
					cout << "Given string is not accepted in the automata\n";
				}
			}else{
				cout << "Invalid String, It must only contain 0s and 1s. Try Again.\n";
			}
		}
	}while(ch!=0);
	
	return 0;
}
