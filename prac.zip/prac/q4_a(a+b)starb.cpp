#include <iostream>
#include <string>
using namespace std;

bool FA(string s){
	char ch = s[0];
	int state = 0;
	int i=0;
	while(i != s.size()){
		ch = s[i];
		if(state == 0){
			if(ch == 'b'){
				return false;
			}else{
				state = 1;
			}
		}else if((state == 1)&&(ch == 'b')){
			state = 2;
		}else if((state == 2)&&(ch == 'a')){
			state = 1;
		}
		i++;
	}

	return (state==2);
}

bool check(string s){
	int i=0;
	while(i!=s.size()){
		char ch = s[i];
		if(ch!='a' && ch!= 'b'){
			return false;
		}
		i++;
	}
	return true;
}

int main(){

	cout << "R.E.: a(a+b)*b\n";
	string s;
	int ch;
	do{
		cout << "========MENU========\n\
0. Exit.\n\
1. Check a string if it belongs to the above automata or not.\n\
Enter Your Choice: ";
		cin >> ch;

		if(ch!=0 && ch!=1){
			cout << "\nInvalid Input, Try Again.\n";
		}

		if(ch == 1){
			string s;
			cout << "Enter string: ";
			cin >> s;
			if(check(s)){
				if(FA(s)){
					cout << "Given string is accepted in the automata\n";
				}else{
					cout << "Given string is not accepted in the automata\n";
				}
			}else{
				cout << "Invalid String, It must only contain 'a' and 'b'. Try Again.\n";
			}
		}
	}while(ch!=0);

	return 0;
}
